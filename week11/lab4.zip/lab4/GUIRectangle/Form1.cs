﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;



namespace GUIRectangle
{
    public partial class Form1 : Form
    {
  
        private ArrayList figures = new ArrayList();
       

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            using (Graphics g = this.CreateGraphics())
            {
                foreach (Figure dohyung in figures)
                {
                    dohyung.Show(g);
                }
                /*
                foreach (Square square in figures)
                {
                    square.Show(g);
                }

                foreach (Circle circle in figures)
                {
                    circle.Show(g);
                }

                foreach (Triangle triangle in figures)
                {
                    triangle.Show(g);
                }*/
            }
        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {
          
            Random random = new Random();
            int left    = random.Next(1, 100);
            int top     = random.Next(1, 100);
            int right   = random.Next(200, 300);
            int bottom  = random.Next(200, 300);
            int width = random.Next(1, 200);
            int OneMoreRandomNumber = random.Next(1,200);

            Rectangle rectangle =  new Rectangle(left, top, right, bottom);
            Square square = new Square(left, top, right, bottom, System.Drawing.Color.Red);
            Circle circle = new Circle(left, top, width);
            Triangle triangle = new Triangle(left, top, right, bottom, width, OneMoreRandomNumber);

            int figure = random.Next(0, 4);

            if (figure == 0)
            {
                figures.Add(rectangle);
            }
            else if (figure == 1)
            {
                figures.Add(square);
            }
            else if (figure == 2)
            {
                figures.Add(circle);
            }
            else if (figure == 3)
            {
                figures.Add(triangle);
            }
                

            Form1_Paint(null, null);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void 불러오기SToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                FileStream fs = new FileStream(openFileDialog.FileName, FileMode.Open);
                BinaryFormatter deserializer = new BinaryFormatter();

                figures = (ArrayList)deserializer.Deserialize(fs);
                fs.Close();

                Form1_Paint(null, null);
            }
        }

        private void 저장하기SToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                Stream st = new FileStream(saveFileDialog.FileName + ".fig", FileMode.Create);
                BinaryFormatter serializer = new BinaryFormatter();

                serializer.Serialize(st, figures);
                st.Close();
            }
        }
    }
}